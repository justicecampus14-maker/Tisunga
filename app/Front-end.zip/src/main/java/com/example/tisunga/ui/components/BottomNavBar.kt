package com.example.tisunga.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.tisunga.ui.navigation.Routes

data class BottomNavItem(
    val label: String,
    val icon: ImageVector,
    val route: String
)

@Composable
fun BottomNavBar(
    navController: NavController,
    type: String = "A"
) {
    val navBackStackEntry by navController
        .currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val items: List<BottomNavItem> = listOf(
        BottomNavItem("Home", Icons.Filled.Home, Routes.HOME),
        BottomNavItem(
            "Savings",
            Icons.Filled.AccountBalance, 
            Routes.GROUP_SAVINGS
        ),
        BottomNavItem("Loans", Icons.Filled.SwapHoriz, Routes.ALL_LOANS)
    )

    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        items.forEach { item ->
            val isSelected = when (item.route) {
                Routes.HOME -> currentRoute == Routes.HOME
                Routes.GROUP_SAVINGS -> currentRoute == Routes.GROUP_SAVINGS || currentRoute?.startsWith("make_contribution") == true || currentRoute?.startsWith("contribution_history") == true
                Routes.ALL_LOANS -> currentRoute == Routes.ALL_LOANS || currentRoute?.startsWith("my_loans") == true || currentRoute?.startsWith("group_loans") == true || currentRoute?.startsWith("apply_loan") == true
                else -> currentRoute == item.route
            }

            NavigationBarItem(
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        fontSize = 11.sp
                    )
                },
                selected = isSelected,
                onClick = {
                    if (item.route == Routes.HOME) {
                        // For HOME, we want to clear everything and go back to start
                        navController.navigate(Routes.HOME) {
                            popUpTo(navController.graph.startDestinationId) {
                                inclusive = true
                            }
                            launchSingleTop = true
                        }
                    } else {
                        // For other tabs, use standard tab switching logic
                        if (currentRoute != item.route) {
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.startDestinationId) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}