package com.example.tisunga

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.example.tisunga.data.remote.ApiClient
import com.example.tisunga.ui.navigation.AppNavGraph
import com.example.tisunga.ui.theme.TisungaTheme
import com.example.tisunga.utils.SessionManager
import com.example.tisunga.viewmodel.*

import androidx.lifecycle.AbstractSavedStateViewModelFactory
import androidx.lifecycle.SavedStateHandle
import androidx.savedstate.SavedStateRegistryOwner

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        ApiClient.init(this)
        val sessionManager = SessionManager(this)

        setContent {
            var isDarkMode by remember { mutableStateOf(sessionManager.isDarkMode()) }

            TisungaTheme(darkTheme = isDarkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color    = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    // Pass 'this' as the owner for the SavedState
                    val factory = ViewModelFactory(sessionManager, this)

                    val authViewModel: AuthViewModel         = viewModel(factory = factory)
                    val groupViewModel: GroupViewModel       = viewModel(factory = factory)
                    val loanViewModel: LoanViewModel         = viewModel(factory = factory)
                    val savingsViewModel: SavingsViewModel   = viewModel(factory = factory)
                    val eventViewModel: EventViewModel       = viewModel(factory = factory)
                    val homeViewModel: HomeViewModel         = viewModel(factory = factory)
                    val notificationViewModel: NotificationViewModel = viewModel(factory = factory)
                    val transactionViewModel: TransactionViewModel = viewModel(factory = factory)
                    val meetingViewModel: MeetingViewModel = viewModel(factory = factory)
                    val userProfileViewModel: UserProfileViewModel = viewModel(factory = factory)

                    AppNavGraph(
                        navController         = navController,
                        sessionManager        = sessionManager,
                        authViewModel         = authViewModel,
                        groupViewModel        = groupViewModel,
                        loanViewModel         = loanViewModel,
                        savingsViewModel      = savingsViewModel,
                        eventViewModel        = eventViewModel,
                        homeViewModel         = homeViewModel,
                        notificationViewModel = notificationViewModel,
                        transactionViewModel  = transactionViewModel,
                        meetingViewModel      = meetingViewModel,
                        userProfileViewModel  = userProfileViewModel,
                        onThemeChange         = { isDarkMode = it }
                    )
                }
            }
        }
    }
}

class ViewModelFactory(
    private val sessionManager: SessionManager,
    owner: SavedStateRegistryOwner
) : AbstractSavedStateViewModelFactory(owner, null) {
    
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(
        key: String,
        modelClass: Class<T>,
        handle: SavedStateHandle
    ): T {
        return when {
            modelClass.isAssignableFrom(AuthViewModel::class.java)    -> AuthViewModel(sessionManager) as T
            modelClass.isAssignableFrom(GroupViewModel::class.java)   -> GroupViewModel(sessionManager, handle) as T
            modelClass.isAssignableFrom(LoanViewModel::class.java)    -> LoanViewModel(sessionManager, handle) as T
            modelClass.isAssignableFrom(SavingsViewModel::class.java) -> SavingsViewModel(sessionManager, handle) as T
            modelClass.isAssignableFrom(EventViewModel::class.java)   -> EventViewModel(sessionManager, handle) as T
            modelClass.isAssignableFrom(HomeViewModel::class.java)    -> HomeViewModel(sessionManager, handle) as T
            modelClass.isAssignableFrom(NotificationViewModel::class.java) -> NotificationViewModel(handle) as T
            modelClass.isAssignableFrom(TransactionViewModel::class.java) -> TransactionViewModel(handle) as T
            modelClass.isAssignableFrom(MeetingViewModel::class.java) -> MeetingViewModel(sessionManager, handle) as T
            modelClass.isAssignableFrom(ContributionViewModel::class.java) -> ContributionViewModel(sessionManager, handle) as T
            modelClass.isAssignableFrom(UserProfileViewModel::class.java) -> UserProfileViewModel(sessionManager, handle) as T
            modelClass.isAssignableFrom(ActivitiesViewModel::class.java) -> ActivitiesViewModel(handle) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
